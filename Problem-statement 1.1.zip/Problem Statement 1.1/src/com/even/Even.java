package com.even;

import java.util.Scanner;


public class Even {
	
	public void even() {
		int i,n;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a No ::");
		n=sc.nextInt();
		
		for(i=1;i<=n;i++)
		{
		if(i%2==0)
			System.out.print(i+ "\t");
		
		}
	}
	public static void main(String[] args) {
		
		Even obj= new Even();
		obj.even();
				
	}

}
