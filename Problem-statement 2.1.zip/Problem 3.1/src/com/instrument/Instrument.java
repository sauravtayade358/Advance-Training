package com.instrument;

public abstract class Instrument

{

protected abstract void Play();
}