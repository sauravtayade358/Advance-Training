//Write a program that accepts two numbers from the Command Line and print them out. Then use a for loop  to print the next 13 numbers in the sequence where each number is the sum of  the previous two. For example:input> java Problem2 1 3output> 1 3 4 7 11 18 29 47 76 123 322 521 843 1364
package com.sump;

import java.util.Scanner;

public class PSum {
	
		  public static void main(String[] args) {

		    int n = 15, firstTerm , secondTerm ;
		    Scanner sc=new Scanner(System.in);
			
			System.out.println("Enter a 1 No ::");
			firstTerm=sc.nextInt();
			
			System.out.println("Enter a  2 No ::");
			secondTerm=sc.nextInt();
			
		    System.out.println("Previous SUM Series till " + n + " terms:");

		    for (int i = 1; i <= n; ++i) {
		      System.out.print(firstTerm + " ");

		      // compute the next term
		      int nextTerm = firstTerm + secondTerm;
		      firstTerm = secondTerm;
		      secondTerm = nextTerm;
		    }
		  }
		

}
