//2.1Write a program that takes a String through Command Line argument and display the length of the string. Also display  the string into  uppercase and  check whether it is a  palindrome  or not. (Refer Java API Documentation)
package com.arg;

import java.util.Scanner;



public class Stringchecking {
	
	Scanner sc= new Scanner(System.in);
	String s,rev = "";
	 
	//for enter an String
	public void enterstring()
	{
        System.out.println("Enter an String::");
        s=sc.next();
        System.out.println("Entered an String::"+s);
	}
	
	public void length() {
		
		System.out.println("String Length is: "+s.length());  
	}

	public void Ucase()
	{
		System.out.println("String in UpperCase::"+s.toUpperCase());
	}
	
	
	public void ChkPalindrome()
	{
	   
	      
	   
	      int length = s.length();
	 
	      for ( int i = length - 1; i >= 0; i-- )
	         rev = rev + s.charAt(i);
	 
	      if (s.equals(rev))
	         System.out.println(s+" is a palindrome");
	      else
	         System.out.println(s+" is not a palindrome");
	 
	   }
	
public static void main(String[] args) {
		
	Stringchecking obj= new Stringchecking();
		obj.enterstring();
		obj.length();
		obj.Ucase();
		obj.ChkPalindrome();
				
	}

	

	
}
